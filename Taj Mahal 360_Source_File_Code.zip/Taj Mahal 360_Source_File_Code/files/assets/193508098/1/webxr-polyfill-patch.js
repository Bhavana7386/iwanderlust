(function(){
    var polyfill = new WebXRPolyfill();
})();