var Spinner = pc.createScript('spinner');

Spinner.attributes.add('timer' , {type : 'number', default: 0});
Spinner.attributes.add('speed' , {type : 'number', default: 0.1});

// update code called every frame
Spinner.prototype.update = function(dt) {

    this.timer += dt;

    if (this.timer > this.speed) {
        this.entity.rotate(0, 0, -30);
        // Reset the timer
        this.timer = 0;
    }

};